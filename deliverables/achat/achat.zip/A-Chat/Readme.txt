1.  Upload files in 'cgi' to the cgi directory and the other files in 'docs' to the html directory.

2.  Set read and write permission to the html directory, the sub-directories, "error" and "tran", as well as logList.dat (in "error") and transcript.dat (in "tran").

3.  Set read, write, and execute permission to the CGI directory and to it's sub-directories, "msgs" and "users".

4.  In the cgi directory, open admin.settings and change the three lines at the top to reflect your server:

    htmlDir=C:/yourpathhere/html/
    htmlURL=http://yourdomain/achat/
    cgiURL=http://yourdomain/cgi-bin/achat/ 

    Important: Note the use of the "/" character to separate directories, rather than the "\" character. 
    Important: URLs and directories should end in a trailing "/". No other lines in the admin.settings file should be changed.

5.  Set read and write permission to admin.settings, colour.rcd, and email.txt

6.  You may now access the chat through your browser. It should be located at:
    http://yourdomain/cgi-bin/achat/login.pl (where http://yourdomain/cgi-bin/achat/ is the URL to the CGI directory)

    You may also access the Administrative Interface at:
    http://yourdomain/cgi-bin/achat/admin.pl
    It is recommended you do so immediately, so that you can change the Administrative Password. The default password is "chat".