#! /usr/bin/perl

# Accessible Chat Program - Login: Login screens, preferences, frameset
# Copyright 2004, Adaptive Technology Resource Centre, U of Toronto
# Written by: Taras Kowaliw, taras.kowaliw@utoronto.ca
# Last Modified: 04.05.04 by Boon-Hau Teh, boonhau.teh@utoronto.ca


BEGIN {
 $cgiDIR = $0;
 $cgiDIR =~ s/login\.pl$//gi;
 push @INC, $cgiDIR if( $cgiDIR ne "" );
}

require "chatutils.ph";

print "Content-type: text/html\n\n";

# Initializing Global Variables
&getCGI();
$chatID = $form{"chatID"};
&defaultPrefs();
if ($chatID) { &getPrefs(); }
$function = $form{"function"};
$password = $form{"password"};
$uniqueID = $form{"uniqueID"};
$firstLoginFlag = 0;
$language = $form{"language"};
@logintext = ();
$menu = 3;
$msgtxt = 9;
$lang = 17;

# Selecting Language and select default if not specified
if (!$language) {
   $language = $admin{"language"};
}
&readLanguage ($language, "login", logintext);

##########################################################
# Main Login Driver

if (!$function) {
    if ($admin{"createID"} =~ /register/) {
        &showLoginControlled();
    } else {
        &showLogin();
    }
    
} elsif ($function =~ /newLogin/) {
    &cleanUp();
    &showNewLogin();

} elsif ($function =~ /requestID/) {
    &showNewIDRequest;
    
} elsif ($function =~ /returningLogin/) {
    &cleanUp();
    &showReturningLogin();

} elsif ($function =~ /signInNew/) {
    if(&checkProposedID($form{"proposedChatID"},$form{"pass1"},$form{"pass2"})) {
        $chatID = $form{"proposedChatID"};
        $password = $form{"pass1"};
        $prefs{"password"} = $password;
        $prefs{"uniqueID"} = time;
        $uniqueID = $prefs{"uniqueID"};
        $prefs{"lastLogin"} = time;
        $prefs{"language"} = $language;
        $prefs{"colour"} = &nextColourClass ($chatID);
        $prefs{"accessLevel"} = 2;
        &writePrefs();
        $firstLoginFlag = 1;
        &showPreferences1();
    } else {
        &showNewLogin();
    }

} elsif ($function =~ /signInReturning/) {
    if (&verify($form{"proposedChatID"},$form{"pass1"})) {
        $chatID = $form{"proposedChatID"};
        $password = $form{"pass1"};
        &getPrefs();
        $uniqueID = $prefs{"uniqueID"};
        $prefs{"lastLogin"} = time;
        $language = $prefs{"language"};
        $prefs{"colour"} = &nextColourClass ($chatID);
        &writePrefs();
        $firstLoginFlag = 1;
        &makeBingFile();
        &showFrameset();
    } else {
        if ($admin{"createID"} =~ /register/) {
            &showLoginControlled();
        } else {
            &showReturningLogin();
        }
    }

} elsif ($function =~ /sendID/) {
    if(&checkProposedID($form{"proposedChatID"},$form{"pass1"},$form{"pass2"})) {
        open (LIST,">>$cgiDIR"."idrequest.lst");
        print LIST "$form{'proposedChatID'} $form{'pass1'} $form{'email'}\n";
        close (LIST);
        &confirmRequest ();
    } else {
        &showNewIDRequest;
    }

} else {
    if (!&securityCheck($form{"uniqueID"})) {
        $msg = $logintext[1+$msgtxt];
        $msg =~ s/<PROPOSEDID>/$form{'uniqueID'}/g;
        $msg =~ s/<EXPECTEDID>/$prefs{'uniqueID'}/g;
        print "$msg <br />\n";
        &printError($logintext[2+$msgtxt],$logintext[3+$msgtxt]);
    }
    $firstLoginFlag = $form{"firstLoginFlag"};
    
    if ($function =~ /showPrefs1/) {
        &getAndWriteFormPrefs();
        &showPreferences1();
    
    } elsif ($function =~ /showPrefs2/) {
        &getAndWriteFormPrefs();
        &showPreferences2();
    
    } elsif ($function =~ /showPrefs3/) {
        &getAndWriteFormPrefs();
        &showPreferences3();    
        
    } elsif ($function =~ /frameset/) {
        &getAndWriteFormPrefs();
        &makeBingFile();
        &showFrameset();

    } else {
        &printError($logintext[4+$msgtxt],$logintext[5+$msgtxt]);
    }
    

}


exit(0);



##########################################################
# Login Functions

sub getAndWriteFormPrefs {
    if ($form{"fontSize"}) { $prefs{"fontSize"} = $form{"fontSize"}; }
    if ($form{"fontFace"}) { $prefs{"fontFace"} = $form{"fontFace"}; }
    if ($form{"colours"}) { $prefs{"colours"} = $form{"colours"}; }
    if ($form{"navigationAidFlag"} || $form{"navigationAidFlag"} =~ /0/) { $prefs{"navigationAidFlag"} = $form{"navigationAidFlag"}; }
    if ($form{"newestFirstFlag"} || $form{"newestFirstFlag"} =~ /0/) { $prefs{"newestFirstFlag"} = $form{"newestFirstFlag"}; }
    if ($form{"onlyNewFlag"} || $form{"onlyNewFlag"} =~ /0/) { $prefs{"onlyNewFlag"} = $form{"onlyNewFlag"}; }
    if ($form{"bingFlag"} || $form{"bingFlag"} =~ /0/) { $prefs{"bingFlag"} = $form{"bingFlag"}; }
    if ($form{"refresh"}) { $prefs{"refresh"} = $form{"refresh"}; }
    if ($form{"language"}) { $prefs{"language"} = $form{"language"}; }
    &writePrefs();
    &getPrefs();
}

sub checkProposedID {
    $minline = 32;
    ($propIDT, $passT1, $passT2) = @_;
    if (!$propIDT) {
        $errMsg = $logintext[1+$minline];
        return 0;    
    }
    if ($propIDT =~ / /i || $propIDT =~ /\W/) {
        $errMsg = $logintext[2+$minline];
        return 0;
    }
    if (-e "users/$propIDT.prefs") {
        $errMsg = $logintext[3+$minline];
        $errMsg =~ s/<PROPOSEDID>/$propIDT/g;
        return 0;
    }
    if (!($passT1 =~ /$passT2/ && $passT2 =~ /$passT1/) || !$passT1) {
        $errMsg = $logintext[4+$minline];
        return 0;
    }
    return 1;
}

sub verify {
    $minline = 39;
    ($propIDT, $passT1) = @_;
    if (!$propIDT) {
        $errMsg = $logintext[1+$minline];
        return 0;
    }
    if (!(-e "users/$propIDT.prefs")) {
        $errMsg = $logintext[2+$minline];
        $errMsg =~ s/<PROPOSEDID>/$propIDT/g;
        return 0;
    }
    $chatID = $propIDT;
    &getPrefs();
    if (!$passT1 || !($passT1 =~ /$prefs{"password"}/ && $prefs{"password"} =~ /$passT1/)) {
        $errMsg = $logintext[3+$minline];
        return 0;
    }
    return 1;
}


###########################################################
# Login Print Functions

sub showLogin {
    $minline = 45;

    &printHead($logintext[1+$minline], $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableRight("<a href=\"#login\">$logintext[1+$menu]</a> | <a href=\"#help\">$logintext[2+$menu]</a>");
    print "<br /><a name=\"login\"></a>\n";

    # Login
    &printTableDark("<h4>$logintext[2+$minline]</h4>");
    print "<p class=\"light\">$logintext[5+$minline]</p>
          <p><a href=\"$loginURL?function=newLogin&language=$language\">$logintext[8+$minline]</a><br />
          <a href=\"$loginURL?function=returningLogin&language=$language\">$logintext[9+$minline]</a>
          </p><a name=\"help\"></a>\n";

    # Help
    &printTableDark("<h4>$logintext[12+$minline]</h4>");
    print "$logintext[14+$minline]<br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$logintext[3+$menu]</a> | $admin{'returnLink'}");    
    print "</body></html>\n";
}

sub showNewLogin {
    $minline = 63;

    if ($errMsg) {
        $printLineT = "<font color=\"red\">$errMsg</font>";
    } else {
        $printLineT = "$logintext[2+$minline]";
    }

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\" onLoad=\"self.focus();document.f1.proposedChatID.focus();\">\n";

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableRight("<a href=\"#login\">$logintext[1+$menu]</a> | <a href=\"#help\">$logintext[2+$menu]</a>");
    print "<br /><a name=\"login\"></a>\n";

    # New User Login
    &printTableDark("<h4>$printLineT</h4>");
    print "<p class=\"light\">$logintext[4+$minline]</p>\n";
    &printFormStart("$loginURL","signInNew","_top");
    print "<p><table border=\"0\" cellpadding=\"5\" cellspacing=\"0\"><tr>
           <td align=\"right\">$logintext[7+$minline]</td><td> <input type=\"text\" maxlength=\"10\" name=\"proposedChatID\" /></td></tr>
           <tr><td align=\"right\">$logintext[8+$minline]</td><td> <input type=\"password\" maxlength=\"10\" name=\"pass1\" /></td></tr>
           <tr><td align=\"right\">$logintext[9+$minline]</td><td> <input type=\"password\" maxlength=\"10\" name=\"pass2\" /></td></tr>
           <tr><td><input type=\"submit\" value=\"$logintext[11+$minline]\" /></td><td></td></tr>
           <input type=\"hidden\" name=\"language\" value=\"$language\" />
           </table></p></form>\n";

    # Help
    &printTableDark("<h4>$logintext[14+$minline]</h4>");
    print "$logintext[16+$minline]<br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$logintext[3+$menu]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

sub showReturningLogin {
    $minline = 83;

    if ($errMsg) {
        $printLineT = "<font color=\"red\">$errMsg</font>";
    } else {
        $printLineT = "$logintext[2+$minline]";
    }

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableRight("<a href=\"#login\">$logintext[1+$menu]</a> | <a href=\"#help\">$logintext[2+$menu]</a>");
    print "<br /><a name=\"login\"></a>\n";

    # Login
    &printTableDark("<h4>$printLineT</h4>");
    print "<p class=\"light\">$logintext[5+$minline]</p>\n";
    &printFormStart("$loginURL","signInReturning","_top");
    print "<p><table border=\"0\" cellpadding=\"5\" cellspacing=\"0\"><tr>
           <td align=\"right\">$logintext[8+$minline] </td><td> <input type=\"text\" maxlength=\"10\" name=\"proposedChatID\" /></td></tr>
           <tr><td align=\"right\">$logintext[9+$minline] </td><td> <input type=\"password\" maxlength=\"10\" name=\"pass1\" /></td></tr>
           <tr><td><input type=\"submit\" value=\"Enter Chat\" /></td><td></td></tr>
           <input type=\"hidden\" name=\"language\" value=\"$language\" />
           </table></p></form>\n";

    # Help
    &printTableDark("<h4>$logintext[12+$minline]</h4>");
    $msg = $logintext[14+$minline];
    $msg =~ s/<LOGINLINK>/$loginURL?function=newLogin/g;
    print "$msg<br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$logintext[3+$menu]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

sub showLoginControlled {
    $minline = 101;

    if ($errMsg) {
        $printLineT = "<font color=\"red\">$errMsg</font>";
    } else {
        $printLineT = "$logintext[2+$minline]";
    }

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableRight("<a href=\"#login\">$logintext[1+$menu]</a> | <a href=\"#help\">$logintext[2+$menu]</a>");
    print "<br /><a name=\"login\"></a>\n";

    # Login
    &printTableDark("<h4>$printLineT</h4>");
    print "<p class=\"light\">$logintext[5+$minline]</p>\n";
    &printFormStart("$loginURL","signInReturning","_top");
    chomp ($logintext [14 + $minline]);
    $logintext[14+$minline] =~ s/<REQUESTLINK>/$loginURL?function=requestID&language=$language/g;
    print "<p><table border=\"0\" cellpadding=\"5\" cellspacing=\"0\"><tr>
           <td align=\"right\">$logintext[8+$minline] </td><td> <input type=\"text\" maxlength=\"10\" name=\"proposedChatID\" /></td></tr>
           <tr><td align=\"right\">$logintext[9+$minline] </td><td> <input type=\"password\" maxlength=\"10\" name=\"pass1\" /></td></tr>
           <tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"$logintext[11+$minline]\" /></td></tr>
           <tr><td colspan=\"2\" align=\"center\">$logintext[14+$minline]</td></tr>
           </table></p>
           <input type=\"hidden\" name=\"language\" value=\"$language\" /></form>\n";

    # Help
    &printTableDark("<h4>$logintext[17+$minline]</h4>");
    $msg = $logintext[19+$minline];
    $msg =~ s/<REQUESTLINK>/$loginURL?function=requestID/g;
    print "$msg<br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$logintext[3+$menu]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

sub showNewIDRequest {
    $minline = 124;	

    if ($errMsg) {
        $printLineT = "<font color=\"red\">$errMsg</font>";
    } else {
        $printLineT = "$logintext[2+$minline]";
    }

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\" onLoad=\"self.focus();document.f1.proposedChatID.focus();\">\n";

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableRight("<a href=\"#login\">$logintext[1+$menu]</a> | <a href=\"#help\">$logintext[2+$menu]</a>");
    print "<br /><a name=\"login\"></a>\n";

    # ID Request
    &printTableDark("<h4>$printLineT</h4>");
    print "<p class=\"light\">$logintext[4+$minline]</p>\n";
    &printFormStart("$loginURL","sendID","_top");
    print "<p><table border=\"0\" cellpadding=\"5\" cellspacing=\"0\"><tr>
           <td align=\"right\">$logintext[7+$minline]</td><td> <input type=\"text\" maxlength=\"10\" name=\"proposedChatID\" /></td></tr>
           <tr><td align=\"right\">$logintext[8+$minline]</td><td> <input type=\"password\" maxlength=\"10\" name=\"pass1\" /></td></tr>
           <tr><td align=\"right\">$logintext[9+$minline]</td><td> <input type=\"password\" maxlength=\"10\" name=\"pass2\" /></td></tr>
           <tr><td align=\"right\">$logintext[10+$minline] </td><td> <input type=\"text\" name=\"email\" /></td></tr>
           <tr><td></td><td><input type=\"submit\" value=\"$logintext[12+$minline]\" /></td><td></td></tr>
           <input type=\"hidden\" name=\"language\" value=\"$language\" />
           </table></p></form>\n";
    &printTableDark("<h4>$logintext[15+$minline]</h4>");
    print "$logintext[17+$minline]<br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$logintext[3+$menu]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

sub confirmRequest {
    $minline = 145;

    &printHead($logintext[1+$minline], $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    &printTableDark("<h4>$admin{'chatName'}$logintext[1+$minline]</h4>");

    print "$logintext[3+$minline]\n";

    print "$logintext[5+$minline]\n";

    &printTableRight("<a href=\"$loginURL\">$logintext[8+$minline]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

# End of Login Printing Functions
#######################################################


#######################################################
# General Printing Functions
sub showFrameset {
    $minline = 157;
    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    if ($prefs{"bingFlag"} > 0 && $prefs{"refresh"} =~ /manual/) {
        print "<frameset cols=\"*,300\" border=\"0\">
                 <frame src=\"$displayURL?function=display&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language\" name=\"display\" />
                 <frameset rows=\"*,5\" border=\"0\">
                   <frame src=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\" name=\"options\" />
                 </frameset>
               </frameset>
               \n";
    } elsif ($prefs{"refresh"} =~ /manual/) {
         print "<frameset cols=\"*,300\" border=\"0\">
                   <frame src=\"$displayURL?function=display&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language\" name=\"display\" />
                   <frame src=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\" name=\"options\" />
               </frameset>
               \n";   
    } else {
         print "<frameset cols=\"*,300\" border=\"0\">
                   <frameset rows=\"*,151\" border=\"0\">
                     <frame src=\"$displayURL?function=display&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language\" name=\"display\" />
                     <frame src=\"$displayURL?function=poster&chatID=$chatID&uniqueID=$uniqueID&language=$language\" name=\"compose\"/>
                   </frameset>
                   <frame src=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\" name=\"options\" />
                   <frame src=\"$htmlURL$chatID.html\" name=\"bing\" />
               </frameset>
               \n";
    }
}

sub makeBingFile {
    open (BING,">$htmlDir$chatID.html") || &printError("Bing File: $htmlDir$chatID.html","$!");

    if (($prefs{"refresh"} =~ /manual/ && $prefs{"bingFlag"} > 0) && ($ENV{"HTTP_USER_AGENT"} =~ /MSIE/i && $ENV{"HTTP_USER_AGENT"} !~ /MAC/i)) {

        print BING "<html><script language=\"vbscript\">
		option explicit
		Dim IntervalID
		Dim count
		count = 0

		sub loaded

		    IntervalID = Window.setInterval(\"askServer\",5000)
		end sub

		sub changedF2
		    askServer
		end sub

		sub askServer
		    Dim objAsp, theFile
		    set objAsp = CreateObject(\"Microsoft.XMLHTTP\")
		    objAsp.open \"GET\", \"$bingURL?uselessVar=\" + CStr(count) + \"&chatID=$chatID\", false
		    objAsp.send()
		    theFile = objAsp.responsetext
		    if InStr(theFile,\"yes\") > 0 then
			Player.URL = \"$htmlURL\" + \"chime.wav\"
		    else
		    end if
		    count = count + 1
		    'document.f1.f2.value = CStr(count) + theFile
		    objAsp = 3
		    theFile = \"\"
		end sub

		</script>
		<body onLoad=\"loaded\" language=\"vbscript\">
		<!--<form name=f1><input type=text name=f2 length=\"200\" /></form>-->
		<OBJECT ID=\"Player\" height=\"0\" width=\"0\" CLASSID=\"CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6\"></OBJECT>
		</body>
		</html>\n";    
    } elsif ($prefs{"refresh"} =~ /manual/ && $prefs{"bingFlag"} > 0) {
        print BING "<html><body bgcolor=\"$prefs{'back'}\">
        <applet code='MachineThatGoesBing.class' width='1' height='1'>
        <param name='chatID' value='$chatID' />
        <param name='url' value='$bingURL' />
        </applet></body></html>\n";
    }
    close(BING);
    chmod (0666,"$htmlDir$chatID.html");
}


# End of General Printing Functions
#######################################################


#######################################################
# Preference Printing Functions
sub showPreferences1 {
    $minline = 162;

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableLeft("<h4>$logintext[2+$minline]</h4>");

    # Message Checking
    &printFormStart("$loginURL","showPrefs2","_top");
    print "<input type=\"hidden\" name=\"firstLoginFlag\" value=\"$firstLoginFlag\" />\n";

    if ($prefs{"refresh"} =~ /manual/i) {
       $mCManSelT = "selected";
    } elsif ($prefs{"refresh"} > 100) {
       $mC180SelT = "selected";
    } elsif ($prefs{"refresh"} > 30) {
       $mC60SelT = "selected";
    } elsif ($prefs{"refresh"} > 10) {
       $mC20SelT = "selected";
    } else {
       $mc5SelT = "selected";
    }

    print "<p><b>$logintext[4+$minline]</b>
           <select name=\"refresh\">
           <option value=\"5\" $mc5SelT>$logintext[6+$minline]</option>
           <option value=\"20\" $mC20SelT>$logintext[7+$minline]</option>
           <option value=\"60\" $mC60SelT>$logintext[8+$minline]</option>
           <option value=\"180\" $mC180SelT>$logintext[9+$minline]</option>
           <option value=\"manual\" $mCManSelT>$logintext[10+$minline]</option>
           </select></p>
           $logintext[13+$minline]\n";

    # New Message
    if ($prefs{"bingFlag"} > 0) {
       $bFSelT = "selected";
    }
    print "<p><b>$logintext[16+$minline]</b>
           <select name=\"bingFlag\">
           <option value=\"0\">$logintext[18+$minline]</option>
           <option value=\"1\" $bFSelT>$logintext[19+$minline]</option>
           </select></p>
           $logintext[21+$minline]\n";

    # Footer
    &printTableLeft("<input type=\"submit\" value=\"$logintext[24+$minline]\" />
                     <input type=\"hidden\" name=\"language\" value=\"$language\" />
                     <input type=\"button\" value=\"$logintext[25+$minline]\" onClick=\"enterChat()\" /></form>");
    print "<script language=\"javascript\"><!--
           function enterChat() {
               var nF = document.f1.refresh[document.f1.refresh.selectedIndex].value;
               var oNF = document.f1.bingFlag[document.f1.bingFlag.selectedIndex].value;
               //window.location.href = \"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag\";;
               window.location.href = \"$loginURL?bingFlag=\"+oNF+\"&refresh=\"+nF+\"&function=frameset&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language\";
           }
           //--></script>\n";
    print "</body></html>\n";
}

sub showPreferences2 {
    $minline = 191;

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableLeft("<h4>$logintext[2+$minline]</h4>");

    &printFormStart("$loginURL","showPrefs3","_top");
    print "<input type=\"hidden\" name=\"firstLoginFlag\" value=\"$firstLoginFlag\" />\n";

    # Order of Messages
    if ($prefs{"newestFirstFlag"} > 0) {
       $nFFSelT = "selected";
    }
    print "<p><b>$logintext[4+$minline]</b>
           <select name=\"newestFirstFlag\">
           <option value=\"0\">$logintext[6+$minline]</option>
           <option value=\"1\" $nFFSelT>$logintext[7+$minline]</option>
           </select></p>
           $logintext[9+$minline]\n";

    # Show Only New Messages
    if ($prefs{"onlyNewFlag"} > 0) {
       $oNFSelT = "selected";
    }
    print "<p><b>$logintext[12+$minline]</b>
           <select name=\"onlyNewFlag\">
           <option value=\"0\">$logintext[14+$minline]</option>
           <option value=\"1\" $oNFSelT>$logintext[15+$minline]</option>
           </select></p>$logintext[17+$minline]

           <script language=\"javascript\"><!--
           function enterChat() {
               var nF = document.f1.newestFirstFlag[document.f1.newestFirstFlag.selectedIndex].value;
               var oNF = document.f1.onlyNewFlag[document.f1.onlyNewFlag.selectedIndex].value;
               window.location.href = \"$loginURL?onlyNewFlag=\"+oNF+\"&newestFirstFlag=\"+nF+\"&function=frameset&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language\";
           }
           //--></script>\n";
           
    # Footer
    &printTableLeft("<input type=\"button\" value=\"$logintext[20+$minline]\" onClick=\"window.location.href='$loginURL?function=showPrefs1&chatID=$chatID&uniqueID=$uniqueID&firstLoginFlag=$firstLoginFlag&language=$language'\" />
                     <input type=\"submit\" value=\"$logintext[21+$minline]\" />
                     <input type=\"hidden\" name=\"language\" value=\"$language\" />
                     <input type=\"button\" value=\"$logintext[22+$minline]\" onClick=\"enterChat()\" /></form>");
    print "</form></body></html>\n";

}

sub showPreferences3 {
    $minline = 217;

    &printHead("$admin{'chatName'}$logintext[1+$minline]", $logintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();

    # Header
    &printTableDark("<h3>$admin{'chatName'}</h3>");
    &printTableLeft("<h4>$logintext[2+$minline]</h4>");

    &printFormStart("$loginURL","frameset","_top");
    print "<input type=\"hidden\" name=\"firstLoginFlag\" value=\"$firstLoginFlag\" />\n";
    print "<p><table border=\"0\" cellpaddin\"5\" cellspacing=\"0\">\n";

    # Font Size
    if ($prefs{"fontSize"} < 11) {
       $fs10SelT = "selected";
    } elsif ($prefs{"fontSize"} < 13) {
       $fs12SelT = "selected";
    } elsif ($prefs{"fontSize"} < 15) {
       $fs14SelT = "selected";
    } else {
       $fs18SelT = "selected";
    } 
    print "<tr><td align=\"right\"><b>$logintext[4+$minline]</b></td><td>
           <select name=\"fontSize\">
           <option value=\"10\" $fs10SelT>$logintext[6+$minline]</option>
           <option value=\"12\" $fs12SelT>$logintext[7+$minline]</option>
           <option value=\"14\" $fs14SelT>$logintext[8+$minline]</option>
           <option value=\"18\" $fs18SelT>$logintext[9+$minline]</option>
           </select></td></tr>\n";

    # Font Face
    if ($prefs{"fontFace"} =~ /arial/i) {
       $fsArialSelT = "selected";
    } elsif ($prefs{"fontFace"} =~ /courier/i) {
       $fsCourierSelT = "selected";
    } else {
       $fsTimesSelT = "selected";
    } 
    print "<tr><td align=\"right\"><b>$logintext[12+$minline]</b></td><td>
           <select name=\"fontFace\">
           <option value=\"arial\" $fsArialSelT>$logintext[14+$minline]</option>
           <option value=\"courier\" $fsCourierSelT>$logintext[15+$minline]</option>
           <option value=\"times\" $fsTimesSelT>$logintext[16+$minline]</option>
           </select></td></tr>\n";

    # Colour Scheme
    if ($prefs{"colours"} =~ /beigeBlack/i) {
       $c1SelT = "selected";
    } elsif ($prefs{"colours"} =~ /whiteBlack/i) {
       $c2SelT = "selected";
    } elsif ($prefs{"colours"} =~ /whiteBlue/i) {
       $c3SelT = "selected";
    } elsif ($prefs{"colours"} =~ /blackYellow/i) {
       $c4SelT = "selected";
    } elsif ($prefs{"colours"} =~ /blackBlue/i) {
       $c5SelT = "selected";
    } else { # blueWhite
       $c6SelT = "selected";
    } 
    print "<tr><td align=\"right\"><b>$logintext[19+$minline]</b></td><td>
           <select name=\"colours\">
           <option value=\"beigeBlack\" $c1SelT>$logintext[21+$minline]</option>
           <option value=\"whiteBlack\" $c2SelT>$logintext[22+$minline]</option>
           <option value=\"whiteBlue\" $c3SelT>$logintext[23+$minline]</option>
           <option value=\"blackYellow\" $c4SelT>$logintext[24+$minline]</option>
           <option value=\"blackWhite\" $c5SelT>$logintext[25+$minline]</option>
           <option value=\"blueWhite\" $c6SelT>$logintext[26+$minline]</option>
           </select></td></tr></table>\n";
    print "$logintext[29+$minline]";

    # Navigation Aids
    if ($prefs{"navigationAidFlag"} > 0) {
       $nAFSelT = "selected";
    }
    print "<p style=\"margin-left: 40;\"><b>$logintext[32+$minline]</b>
           <select name=\"navigationAidFlag\">
           <option value=\"0\">$logintext[34+$minline]</option>
           <option value=\"1\" $nAFSelT>$logintext[35+$minline]</option>
           </select></p>
           $logintext[37+$minline]\n";

    # Language Settings
    if ($prefs{"language"} =~ /French/) {
       $fre = "selected";
    } elsif ($prefs{"language"} =~ /Chinese/) {
       $chi = "selected";
    } elsif ($prefs{"language"} =~ /German/) {
       $ger = "selected";
    } elsif ($prefs{"language"} =~ /Italian/) {
       $ita = "selected";
    } elsif ($prefs{"language"} =~ /Japanese/) {
       $jap = "selected";
    } elsif ($prefs{"language"} =~ /Korean/) {
       $kor = "selected";
    } elsif ($prefs{"language"} =~ /Portuguese/) {
       $por = "selected";
    } elsif ($prefs{"language"} =~ /Spanish/) {
       $spa = "selected";
    } else {
       $eng = "selected";
    } 

    print "<p style=\"margin-left: 40;\"><b>$logintext[40+$minline]</b>
           <select name=\"language\">
           <option value=\"English\" $eng>$logintext[2+$lang]</option>
           <option value=\"French\" $fre>$logintext[3+$lang]</option>
           <option value=\"Chinese\" $chi>$logintext[4+$lang]</option>
           <option value=\"German\" $ger>$logintext[5+$lang]</option>
           <option value=\"Italian\" $ita>$logintext[6+$lang]</option>
           <option value=\"Japanese\" $jap>$logintext[7+$lang]</option>
           <option value=\"Korean\" $kor>$logintext[8+$lang]</option>
           <option value=\"Portuguese\" $por>$logintext[9+$lang]</option>
           <option value=\"Spanish\" $spa>$logintext[10+$lang]</option>
           </select></p>\n";
    print "$logintext[42+$minline]\n";

    # Footer
    &printTableLeft("<input type=\"button\" value=\"$logintext[46+$minline]\" onClick=\"window.location.href='$loginURL?function=showPrefs2&chatID=$chatID&uniqueID=$uniqueID&language=$language';\" />
                     <input type=\"submit\" value=\"$logintext[47+$minline]\" /></form>");
    print "</form></body></html>\n";

}

# End of Preference Printing Functions
#######################################################
