#! /usr/bin/perl

# Accessible Chat Program - Display: display screen, history screen
# Copyright 2004, Adaptive Technology Resource Centre, U of Toronto
# Written by: Taras Kowaliw, taras.kowaliw@utoronto.ca
# Last Modified: 04.05.04 by Boon-Hau Teh, boonhau.teh@utoronto.ca



BEGIN {
 $cgiDIR = $0;
 $cgiDIR =~ s/display\.pl$//gi;
 push @INC, $cgiDIR if( $cgiDIR ne "" );
}

require "chatutils.ph";

print "Content-type: text/html\n\n";

# Initializing Global Variables
&getCGI();
$chatID = $form{"chatID"};

&getPrefs();
$function = $form{"function"};
$uniqueID = $form{"uniqueID"};
$firstLoginFlag = $form{"firstLoginFlag"};

$language = $prefs {"language"};
@displaytext = ();
$msgtxt = 3;

# Selecting Language and select default if not specified
if (!$language) {
   $language = $admin{"language"};
}
&readLanguage ($language, "display", displaytext);


if (!$chatID || !&securityCheck($uniqueID)) {
    printError($displaytext[1+$msgtxt],$displaytext[2+$msgtxt]);
}

if ($function =~ /display/) {
    $firstLoginFlag = $form{"firstLoginFlag"};
    if ($firstLoginFlag > 0) {
        chomp($displaytext[3+$msgtxt]);
        chomp($displaytext[4+$msgtxt]);
        $displaytext[4+$msgtxt] =~ s/<CHATID>/$chatID/g;
        &postMessage("$displaytext[3+$msgtxt]!",$displaytext[4+$msgtxt]);
    }
    &howManyMessages();
    &showDisplay();
    $prefs{"lastRead"} = $topMsgNum;
    $prefs{"lastChecked"} = $topMsgNum;
    &writePrefs();
    
} elsif ($function =~ /poster/) {
    &showPoster();

} elsif ($function =~ /postMessage/) {
    $message = $form{"message"};
    $message =~ s/[\n]/<br>/gi;
    $message =~ s/  /&nbsp;&nbsp;/g;
    if ($prefs{"accessLevel"} == 3) {
        $errMsg = $displaytext[5+$msgtxt];
    } else {
        &postMessage($chatID,$message);
    }
    &howManyMessages();
    $prefs{"lastRead"} = $topMsgNum;
    $prefs{"lastChecked"} = $topMsgNum;
    &writePrefs();
    &showDisplay();

} elsif ($function =~ /history/) {
    &cleanUp();
    &howManyMessages();
    $hisTopNum = $form{"hisTopNum"};
    if ($hisTopNum > $topMsgNum) { $hisTopNum = $topMsgNum; }
    if (!$hisTopNum) { $hisTopNum = $topMsgNum; };
    $hisBottomNum = &getLower20Bound($hisTopNum);
    if ($hisBottomNum == 0) { $hisBottomNum = 1; }
    $totalNum = $topMsgNum - $bottomMsgNum + 1;
    &showHistory();

} elsif ($function =~ /filterHis/) {
    &cleanUp();
    &howManyMessages();
    $filterChatID = $form{"filterChatID"};
    &showFilterHis();

} else {
    &printError($displaytext[6+$msgtxt],$displaytext[7+$msgtxt]);
}

exit(0);

####################################################
# Utility Functions

sub getLower20Bound {
    $topNumT = @_[0];
    for ($iT=$topNumT; ($iT-$bottomMsgNum)%20 !=0; $iT--) { ; }
    return $iT;
    
}

sub showMessage {
    $mNumT = @_[0];
    if (-e "$cgiDIR"."msgs/$mNumT.message") {
        open(MSG,"<$cgiDIR"."msgs/$mNumT.message") || &printError("<$cgiDIR"."msgs/$mNumT.message","$!");
        chomp ($senderT = <MSG>);
        chomp ($msgT = <MSG>);
        chomp ($class = <MSG>);
        close (MSG);
        if ($mNumT > $prefs{"lastRead"}) {
            if ($class =~ /system/ || $class =~ /hidden/) {
                print "<script language=\"javascript\"><!--
                         if (window.top != window.self)
                             parent.options.location=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\";
                       //--></script>\n";
            }
        }
        if ($class =~ /hidden/) {
            return 0;
        } else {
            if ($mNumT > $prefs{"lastRead"}) {
                print "<tr class=\"$class\"><td width=\"75\"><b>$senderT</b></td><td>$msgT</td></tr>\n";        
            } else {
                print "<tr class=\"$class\"><td width=\"75\">$senderT</td><td>$msgT</td></tr>\n";
            }
        }
    }
    return 1;
}

sub showMessageFiltered {
    ($mNumT,$filterNameT) = @_;
    if (-e "$cgiDIR"."msgs/$mNumT.message") {
        open(MSG,"<$cgiDIR"."msgs/$mNumT.message") || &printError("<$cgiDIR"."msgs/$mNumT.message","$!");
        chomp ($senderT = <MSG>);
        chomp ($msgT = <MSG>);
        chomp ($class = <MSG>);
        close (MSG);
        if (!($class =~ /hidden/) && (($senderT =~ /$filterNameT/ && $filterNameT =~ /$senderT/) || ($senderT =~ /$chatID/ && $chatID =~ /$senderT/))) {
            if ($mNumT > $prefs{"lastRead"}) {
                print "<tr class=\"$class\"><td width=\"75\"><b>$senderT</b></td><td>$msgT</td></tr>\n";
            } else {
                print "<tr class=\"$class\"><td width=\"75\">$senderT</td><td>$msgT</td></tr>\n";
            }
        }
    }
}

# End of Utility Functions
####################################################

####################################################
# Printing Functions

sub showDisplay {
    $minline = 14;

    &printHead($displaytext[1+$minline], $displaytext[1]);

    # Autorefresh
    if ($prefs{"refresh"} !~ /manual/) {
        $timeoutT = $prefs{"refresh"} * 1000;        
        print "<script language=\"javascript\"><!--
               top.AutoRefresh = true;
               setTimeout(\"reDisplay()\", $timeoutT);
               function reDisplay() {                  
                  if (top.AutoRefresh == true)
                     window.location.href = \"$displayURL?chatID=$chatID&function=display&uniqueID=$uniqueID&language=$language\";
               }
               //--></script>\n";
    }

    &printStylesheet();
    &messageColours();

    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    if ($errMsg) {
        print "<font color=\"red\">$errMsg<br> $message</font>\n";
        print "<script language=\"javascript\"><!--
               if (window.top != window.self)
                     parent.options.location=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\";
               //--></script>\n";
    }

    print "<a name=\"messages\"></a>\n";
    &printTableDark("<h4>$displaytext[3+$minline]</h4>");
    
    $min = 1;
    if ($topMsgNum - 10 > 1) { $min = $topMsgNum - 10; }
    #if ($firstLoginFlag > 0) { $min = $bottomMsgNum; }
    #if ($topMsgNum - $min > 50) { $min = $topMsgNum - 50; }
    if ($prefs{"onlyNewFlag"} > 0) { $min = $prefs{"lastRead"} + 1; }

    if ($min <= $topMsgNum) {
        print "<p><table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" width=\"90%\">\n";
    } else {
        print "<p>$displaytext[4+$minline]</p>\n";
    }
    if ($prefs{"newestFirstFlag"} > 0) {
        $end = $min;
        for ($i = $topMsgNum; $i >= $end; $i--) {
            while (&showMessage($i) == 0) {
                $i--;
                $end--;
            }
        }
    } else {
        $end = $topMsgNum;
        for ($i = $min; $i <= $end ; $i++) {
            while (&showMessage($i) == 0) {
                $i++;
                $end++;
            }
        }    
    }
    if ($min <= $topMsgNum) { print "</table></p>\n"; }
    if ($prefs{"navigationAidFlag"} > 0) {
        &printTableRight("<label accesskey=\"m\" for=\"messageQ\"><a href=\"#messages\" id=\"messageQ\">$displaytext[5+$minline]</a></label> | 
                          <label accesskey=\"r\" for=\"refreshQ\"><a id=\"refreshQ\" href=\"$displayURL?function=display&chatID=$chatID&uniqueID=$uniqueID\" target=\"display\">$displaytext[6+$minline]</a></label>");
    } else {
        &printTableRight("<label accesskey=\"r\" for=\"refreshQ\"><a id=\"refreshQ\" href=\"$displayURL?function=display&chatID=$chatID&uniqueID=$uniqueID\" target=\"display\">$displaytext[6+$minline]</a></label>");    
    }
    
    print "<br /><br />\n";
    if ($prefs{"refresh"} =~ /manual/) {
        &posterManual();
    } else {
        if ($prefs{"bingFlag"} > 0 && $topMsgNum > $prefs{"lastRead"}) {
            print "<embed src=\"$soundFile\" loop=\"false\" autoplay=\"true\" play=\"true\" hidden=\"true\" width=\"1\" height=\"1\" />\n";
        }
    }
    print "</body></html>\n";
}

sub showPoster {
    $minline = 23;

    &printHead($displaytext[1+$minline], $displaytext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\" ";

    if ($prefs{"refresh"} =~ /manual/) {
       print "onLoad=\"self.focus();document.f1.message.focus();\" >\n";
    }
    else {
       print "onLoad=\"self.focus();document.f1.tempField.focus();\" >\n";
    }

    &poster();
    print "</body></html>\n";
}


sub poster {
    $minline = 27;

    &printTableDark("<h4>$displaytext[1+$minline]</h4>");
    print "<p class=\"light\">\n";
    print "<form action=\"$displayURL\" target=\"display\" name=\"f1\" method=\"post\" onSubmit=\"top.AutoRefresh=false; return checkForm(); \">
           <input type=\"hidden\" name=\"function\" value=\"postMessage\" />
           <input type=\"hidden\" name=\"chatID\" value=\"$chatID\" />
           <input type=\"hidden\" name=\"uniqueID\" value=\"$uniqueID\" />
           <input type=\"hidden\" name=\"message\" value=\"1\" />
           <label accesskey=\"c\" for=\"tempField\">\n";

    if ($admin{'maxChar'} < 0){
        print "<textarea name=\"tempField\" id=\"tempField\" value=\"$message\" cols=\"42\" rows=\"4\"></textarea>\n";
    }
    else{
        print "<input type=\"text\" maxlength=\"$admin{'maxChar'}\" size=\"50\" name=\"tempField\" id=\"tempField\" value=\"$message\" />\n";
    }

    print "</label>\n<label accesskey=\"s\" for=\"submit\"><input type=\"submit\" value=$displaytext[2+$minline] id=\"submit\" /></label>\n";
    print "</form></p>\n";
    print "<script language=\"javascript\"><!--
           function checkForm() {
               document.f1.message.value = document.f1.tempField.value;
               self.focus();document.f1.tempField.focus();
               if (document.f1.message.value == \"\" || document.f1.message.value == \" \" || !document.f1.message.value) {
                  self.focus();document.f1.tempField.focus();
                  return false;
               }
               document.f1.tempField.value = \"\";
               return true;
           }\n";
    print "//--></script>\n";
}

sub posterManual {
    $minline = 32;

    &printTableDark("<h4>$displaytext[1+$minline]</h4>");
    print "<p class=\"light\">\n";
    print "<form action=\"$displayURL\" target=\"display\" name=\"f1\" method=\"post\" onSubmit=\"top.AutoRefresh=false; return checkForm();\">
           <input type=\"hidden\" name=\"function\" value=\"postMessage\" />
           <input type=\"hidden\" name=\"chatID\" value=\"$chatID\" />
           <input type=\"hidden\" name=\"uniqueID\" value=\"$uniqueID\" />
           <label accesskey=\"c\" for=\"message\">\n";

    if ($admin{'maxChar'} < 0){
        print "<textarea NAME=\"message\" id=\"message\" value=\"\" cols=\"42\" rows=\"4\"></textarea>\n";
    }
    else{
        print "<input type=\"text\" maxlength=\"$admin{'maxChar'}\" size=\"50\" id=\"message\" name=\"message\" value=\"\" />\n";
    }

    print "</label>\n<label accesskey=\"s\" for=\"submit\"><input type=\"submit\" value=\"$displaytext[2+$minline]\" id=\"submit\" /></label>\n";
    print "</form></p>\n";
    print "<script language=\"javascript\"><!--
           self.focus();document.f1.message.focus();
           function checkForm() {
               if (document.f1.message.value == \"\" || document.f1.message.value == \" \" || !document.f1.message.value) {
                  self.focus();document.f1.message.focus();
                  return false;
               }
               return true;
           }\n";
    print "//--></script>\n";
}

sub showHistory {
    $minline = 36;

    &printHead($displaytext[1+$minline], $displaytext[1]);
    &printStylesheet();
    &messageColours();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();
    $hisTopNumUserPerspective = $hisTopNum - $bottomMsgNum + 1;
    $hisBottomNumUserPerspective = $hisBottomNum - $bottomMsgNum + 1;    
    if ($hisBottomNumUserPerspective < 1) { $hisBottomNumUserPerspective = 1; }

    # Header
    &printTableDark("<h3>$admin{'chatName'}$displaytext[3+$minline] $hisBottomNumUserPerspective $displaytext[4+$minline] $hisTopNumUserPerspective $displaytext[5+$minline] $totalNum $displaytext[6+$minline]</h3>");    
    $prevNumT = $hisBottomNum - 1;
    $nextNumT = $hisTopNum + 20;
    if ($hisTopNum < $topMsgNum && $hisBottomNum > $bottomMsgNum) {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$prevNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[8+$minline]</a> |
                          <a href=\"$displayURL?hisTopNum=$nextNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[9+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[10+$minline]</a>");
    } elsif ($hisBottomNum > $bottomMsgNum) {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$prevNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[12+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[13+$minline]</a>");
    } else {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$nextNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[15+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[16+$minline]</a>");
    }

    # Display Messages
    print "<p><table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" width=\"90%\">\n";
    if ($prefs{"newestFirstFlag"} > 0) {
        for ($i = $hisTopNum; $i >= $hisBottomNum; $i--) {
            &showMessage($i);
        }
    } else {
        for ($i = $hisBottomNum; $i <= $hisTopNum ; $i++) {
            &showMessage($i);
        }    
    }
    print "</table></p>\n";

    # Footer
    if ($hisTopNum < $topMsgNum && $hisBottomNum > $bottomMsgNum) {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$prevNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[19+$minline]</a> |
                          <a href=\"$displayURL?hisTopNum=$nextNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[20+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[21+$minline]</a>");
    } elsif ($hisBottomNum > $bottomMsgNum) {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$prevNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[23+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[24+$minline]</a>");
    } else {
        &printTableRight("<a href=\"$displayURL?hisTopNum=$nextNumT&chatID=$chatID&function=history&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[26+$minline]</a> |
                          <a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[27+$minline]</a>");
    }
    print "<br /><br />\n";
    print "</body></html>\n";
}

sub showFilterHis {
    $minline = 66;

    &printHead($displaytext[1+$minline], $displaytext[1]);
    &printStylesheet();
    &messageColours();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();

    # Header
    &printTableDark("<h3>$admin{'chatName'}$displaytext[2+$minline]</h3>");
    &printTableRight("<a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[4+$minline]</a>");

    # Display Messages
    print "<p><table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" width=\"90%\">\n";
    if ($prefs{"newestFirstFlag"} > 0) {
        for ($i = $topMsgNum; $i >= 1; $i--) {
            &showMessageFiltered($i,$filterChatID);
        }
    } else {
        for ($i = 1; $i <= $topMsgNum ; $i++) {
            &showMessageFiltered($i,$filterChatID);
        }    
    }
    print "</table></p><br />\n";

    # Footer
    &printTableRight("<a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$displaytext[4+$minline]</a>");
    print "</body></html>\n";
}

# End of Printing Functions
####################################################


