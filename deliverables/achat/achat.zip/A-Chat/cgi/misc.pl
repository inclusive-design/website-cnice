#! /usr/bin/perl

# Accessible Chat Program - Miscellany: Options, Help, Logout
# Copyright 2004, Adaptive Technology Resource Centre, U of Toronto
# Written by: Taras Kowaliw, taras.kowaliw@utoronto.ca
# Last Modified: 04.05.04 by Boon-Hau Teh, boonhau.teh@utoronto.ca


BEGIN {
 $cgiDIR = $0;
 $cgiDIR =~ s/misc\.pl$//gi;
 push @INC, $cgiDIR if( $cgiDIR ne "" );
}

require "chatutils.ph";

print "Content-type: text/html\n\n";

# Initializing Global Variables
&getCGI();
$chatID = $form{"chatID"};
&getPrefs();
$function = $form{"function"};
$uniqueID = $form{"uniqueID"};

$language = $form{"language"};
@misctext = ();
$msgtxt = 3;
$lang = 14;

# Selecting Language and select default if not specified
if (!$language) {
   $language = $admin{"language"};
}
&readLanguage ($language, "misc", misctext);


if ($function =~ /options/) {
    &showOptions();

} elsif ($function =~ /ctrlusr/) {
    %usrAl;
    opendir(USERS,"$cgiDIR"."users") || &printError("","$!");
    @userFiles = readdir(USERS);
    closedir(USERS);
    foreach $selUsr (sort @userFiles) {
        if ($selUsr =~ /.al/) {
            $selUsr =~ s/\.al//;
            $lA = &getLastAccessed($selUsr);
            if ($lA == 0 || !$lA) {         ## User is currently not in room
                $lA = 0;
            } elsif ($form{$selUsr} =~ /allow/) {    ## Access level is set to 2
                $chatID = $selUsr;
                &getPrefs();
                $prefs{'accessLevel'} = "2";
                &writePrefs();
                $chatID = $form{'chatID'};
                &getPrefs();
            } else {                        ## Access level might be 1 or 3 so check first
                open (USERS,"<$cgiDIR"."users/$selUsr.al");
                $value = <USERS>;
                close(USERS);
                if ($value != 1) {          ## Record change if not moderator (1)
                    $chatID = $selUsr;
                    &getPrefs();
                    $prefs{'accessLevel'} = "3";
                    &writePrefs();
                    $chatID = $form{'chatID'};
                    &getPrefs();
                }
            }
        }
    }
    &postMessage("$misctext[$msgtxt+1]!", $misctext[$msgtxt+2]);
    &showOptions();
    
} elsif ($function =~ /requestSpeak/) {
    if ($prefs{'accessLevel'} eq "3!") {
        $prefs{'accessLevel'} = "3";
    } elsif ($prefs{'accessLevel'} eq "3") {
        $prefs{'accessLevel'} = "3!";
    }
    &writePrefs();
    &postMessage("$chatID#", $misctext[$msgtxt+3]);
    &showOptions();

} elsif ($function =~ /help/) {
    &showHelp();

} elsif ($function =~ /logout/) {
    chomp ($misctext[4+$msgtxt]);
    chomp ($misctext[5+$msgtxt]);

    $misctext[5+$msgtxt] =~ s/<CHATID>/$chatID/g;

    &postMessage("$misctext[4+$msgtxt]!",$misctext[5+$msgtxt]);
    &resetColourClass ($prefs{"colour"});
    $prefs{"lastAccessed"} = 0;
    &writePrefs();
    &showLogout();

} elsif ($function =~ /delete/) {
    &deleteUser($chatID);
    &showDelete();

} else {
    &printError($misctext[6+$msgtxt],$misctext[7+$msgtxt]);

}

exit(0);

####################################################
# Utility Functions

sub printUserList {
    $startline = 29;

    if ($prefs{'accessLevel'} == 1){
        print "<form action=\"$miscURL\" name=\"f1\" method=\"post\">
           <input type=\"hidden\" name=\"chatID\" value=\"$chatID\" />
           <input type=\"hidden\" name=\"uniqueID\" value=\"$prefs{'uniqueID'}\" />
           <input type=\"hidden\" name=\"function\" value=\"ctrlusr\" />
           <input type=\"submit\" value=\"$misctext[1+$startline]\"/>\n";
    } elsif ($prefs{'accessLevel'} eq "3") {
        &printFormStart("$miscURL","requestSpeak");
        print "<input type=\"submit\" value=\"$misctext[2+$startline]\" />\n";
    } elsif ($prefs{'accessLevel'} =~ /3!/) {
        &printFormStart("$miscURL","requestSpeak");
        print "<input type=\"submit\" value=\"$misctext[3+$startline]\" />\n";
    }

    print "<ul>\n";
    opendir(USERS,"$cgiDIR"."users") || &printError("","$!");
    @userFiles = readdir(USERS);
    closedir(USERS);
    foreach $fileT (sort @userFiles) {
        if (index ($fileT, ".prefs") > 0) {
            $fileT =~ s/\.prefs//;
            $lA = &getLastAccessed($fileT);
            $fooT = time;

            # If user is offline
            if ($lA == 0 || !$lA) { 
                $lA = 0;
            }

            # Else if user is online and still active
            elsif ($fooT - $lA < $admin{"chatSessionLifeSpan"}) {
                open (USERS,"$cgiDIR"."users/$fileT.al");
                $access = <USERS>;
                $class = <USERS>;
                close(USERS);
                chomp ($access);
                chomp ($class);

                # If this user is YOU
                if ($fileT eq $chatID) {
                    print "<li><a href=\"$displayURL?function=filterHis&chatID=$chatID&uniqueID=$uniqueID&filterChatID=$fileT&language=$language\" target=\"_top\" class=\"$class\"><b>$fileT</b></a> $misctext[4+$startline]</li>\n";
                }

                # Else it's some other user
                else {
                    print "<li>";

                    # If you are the moderator
                    if ($prefs{'accessLevel'} == 1){
                        if ($access == 2) {
                            print "<input type=\"checkbox\" name=\"$fileT\" value=\"allow\" checked/>";
                        } elsif ($access == 3) {
                            print "<input type=\"checkbox\" name=\"$fileT\" value=\"allow\" />";
                        }
                    }

                    print " <a href=\"$displayURL?function=filterHis&chatID=$chatID&uniqueID=$uniqueID&filterChatID=$fileT&language=$language\" target=\"_top\" class=\"$class\">$fileT</a></li>\n";
                }

                # If the user is being muted
                if ($access == 3) {
                    if (index($access,"!") == length($access)-1) {
                        print "<font color=\"red\">$misctext[5+$startline]</font>";
                    } else {
                        print "<i>$misctext[6+$startline]</i>";
                    }
                }
            }

            # Else user has been inactive and will be logged out
            else {
                &resetLastAccessed($fileT);
                chomp ($misctext[7+$startline]);
                chomp ($misctext[8+$startline]);
                $misctext[8+$startline] =~ s/<CHATID>/$fileT/g;
                &postMessage("$misctext[7+$startline]!",$misctext[8+$startline]);
                &howManyMessages();
            }
        }
    }
    print "</ul>\n";
    if ($prefs{'accessLevel'} != 2) {
        print "</form>\n";
    }
}


# End of Utility Functions
####################################################

####################################################
# Printing Functions

sub showOptions {
    $minline = 42;

    &printHead($misctext[1+$minline], $misctext[1]);
    &printStylesheet();
    &messageColours();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\" />\n";
    &forcelogout();

    # Options
    &printTableDark("<h4>$misctext[2+$minline]</h4>");
    &printTableRight("<a href=\"$loginURL?function=showPrefs1&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[4+$minline]</a>
                      | <label accesskey=\"q\" for=\"help\"><a id=\"help\" href=\"$miscURL?function=help&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[5+$minline]</a></label>
                      | <a href=\"$miscURL?function=logout&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[6+$minline]</a>\n");
    print "<br /><br />\n";

    # User List and History
    &printTableDark("<h4>$misctext[8+$minline]</h4>");
    &printTableRight("<a href=\"$displayURL?function=history&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[10+$minline]</a> | 
                      <a href=\"$miscURL?function=options&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"options\">$misctext[11+$minline]</a>");

    # Display Online Users
    &printUserList();

    # Navigation Aid
    if ($prefs{"navigationAidFlag"} > 0) {
        print "<br /><br />\n";
        &printTableDark("<h4>$misctext[13+$minline]</h4>");
        print "<p class=\"light\">$misctext[15+$minline]</p>\n";
        print "<ul><li>$misctext[17+$minline]</li>
               <li>$misctext[18+$minline]</li>
               <li>$misctext[19+$minline]</li>
               <li>$misctext[20+$minline]</li>
               <li>$misctext[21+$minline]</li></ul>\n";
    }
}

sub showHelp {
    $minline = 67;

    &printHead($misctext[1+$minline], $misctext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &forcelogout();

    # Header
    &printTableDark("<h3>$admin{'chatName'}$misctext[2+$minline]");
    &printTableRight("<a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[5+$minline]</a>");

    # Jump
    print "<a name=\"#jumps\"></a><p>
           <a href=\"#display\">$misctext[7+$minline]</a><br />
           <a href=\"#options\">$misctext[8+$minline]</a><br />
           <a href=\"#history\">$misctext[9+$minline]</a></p>
           <a name=\"display\"></a>\n";
           
    # Display Frame Help
    &printTableLeft("<h4>$misctext[12+$minline]</h4>");
    print "$misctext[14+$minline]\n";
    
    print "<ul><li>$misctext[16+$minline]</li>
           <li>$misctext[17+$minline]</li>
           <li>$misctext[18+$minline]</li>
           <li>$misctext[19+$minline]</li>
           <li>$misctext[20+$minline]</li></ul>
           <p><a href=\"#jumps\">$misctext[22+$minline]</a>
           </p><a name=\"options\"></a>\n";
    
    # Options Help
    &printTableLeft("<h4>$misctext[25+$minline]</h4>");

    print "<ul><li>$misctext[27+$minline]</li>
           <li>$misctext[28+$minline]</li>
           <li>$misctext[29+$minline]</li>
           <!-- <li>$misctext[30+$minline]</li> //-->
           </ul>
           <p><a href=\"#jumps\">$misctext[31+$minline]</a>
           </p><a name=\"history\"></a>\n";

    # User List and History Help
    &printTableLeft("<h4>$misctext[34+$minline]</h4>");

    print "<p>$misctext[36+$minline]
           <br /><br />
           <a href=\"#jumps\">$misctext[38+$minline]</a>
           </p>\n";           

    # Footer
    &printTableRight("<a href=\"$loginURL?function=frameset&chatID=$chatID&uniqueID=$uniqueID&language=$language\" target=\"_top\">$misctext[40+$minline]</a>");
    print "</body></html>\n";
}

sub showLogout {
    $minline = 111;

    &printHead($misctext[1+$minline], $misctext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    &printTableDark("<h4>$admin{'chatName'}$misctext[2+$minline]</h4>");

    print "$misctext[4+$minline]\n";
    $misctext[7+$minline] =~ s/<DELETEURL>/$miscURL?chatID=$chatID&function=delete&uniqueID=$uniqueID&language=$language/g;
    print "$misctext[7+$minline]\n";
           
    print "$misctext[9+$minline]\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$misctext[12+$minline]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

sub showDelete {
    $minline = 127;

    &printHead($misctext[1+$minline], $misctext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";

    &printTableDark("<h4>$admin{'chatName'}$misctext[2+$minline]</h4>");

    print "$misctext[4+$minline]\n";
           
    print "$misctext[6+$minline]\n";

    # Footer
    &printTableRight("<a href=\"$loginURL\">$misctext[9+$minline]</a> | $admin{'returnLink'}");
    print "</body></html>\n";
}

# End of Printing Functions
####################################################


