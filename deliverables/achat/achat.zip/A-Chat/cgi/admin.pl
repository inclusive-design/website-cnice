#! /usr/bin/perl

# Accessible Chat Program - Administrative Script
# Copyright 2004, Adaptive Technology Resource Centre, U of Toronto
# Written by: Taras Kowaliw, taras.kowaliw@utoronto.ca
# Last Modified: 04.05.04 by Boon-Hau Teh, boonhau.teh@utoronto.ca


BEGIN {
 $cgiDIR = $0;
 $cgiDIR =~ s/admin\.pl$//gi;
 push @INC, $cgiDIR if( $cgiDIR ne "" );
}


require "chatutils.ph";
require "email.ph";

print "Content-type: text/html\n\n";

# Initializing Global Variables
$adminURL = $cgiURL . "admin.pl";
&getCGI();
$adminPass = $form{"adminPass"};
&defaultPrefs();
$function = $form{"function"};
$tranlist = "transcript.dat";
$logList = "logList.dat";

$language = $admin{"language"};
@admintext = ();
$lang = 4;
$msgtxt = 27;

# Select English language as default
if (!$language) {
   $language = "English";
}
&readLanguage ($language, "admin", admintext);


# For some reason I have to do this in order to use two submit buttons in one form while keeping things internationalized
# IMPORTANT: Remember to explicitly change these values if editing the language files
$activateuser = $admintext[229];
$declinerequest = $admintext[230];
$setuseraccess = $admintext[241];
$deletethisuser = $admintext[242];


if (!$function) {
    &showLogin();
    
} elsif ($function =~ /admin/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { &showAdmin(); }

} elsif ($function =~ /settings/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[$msgtxt+1]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $admin{"adminPass"} = $form{"newAdminPass"};
        $adminPass = $admin{"adminPass"};
        $admin{"chatName"} = $form{"chatName"};
        $admin{"returnL"} = $form{"returnL"};
        $admin{"returnT"} = $form{"returnT"};
        $admin{"msgLifeSpan"} = $form{"msgLifeSpan"};
        $admin{"chatSessionLifeSpan"} = $form{"chatSessionLifeSpan"};
        $admin{"chatIDLifeSpan"} = $form{"chatIDLifeSpan"};
        $admin{"language"} = $form{"language"};
        $language = $admin{"language"};
        &readLanguage ($language, "admin", admintext);
        if ($form{"maxChar"} =~ / /i || $form{"maxChar"} =~ /\W/ || $form{"maxChar"} =~ /[A-z]/) {
            $admin{"maxChar"} = 200;
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[$msgtxt+4]</b></font><br />\n";
        }
        else {
            $admin{"maxChar"} = $form{"maxChar"};
        }
        if ($form{"noMax"} =~ /infChar/){
            $admin{"maxChar"} = -1;
        }
        &writeAdminSettings();
        if ($form{"page"} =~ /Logs/) {
            &showLogs();
        } elsif ($form{"page"} =~ /Manage Users/) {
            &showUsers();
        } else {
            &showAdmin();
        }
    }

} elsif ($function =~ /changePage/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[$msgtxt+1]<br /><br /></b>\n";
        &showLogin();
    } else {
        if ($form{"page"} =~ /Logs/) {
            &showLogs();
        } elsif ($form{"page"} =~ /Manage Users/) {
            &showUsers();
        } else {      
            &showAdmin();
        }
    }

} elsif ($function =~ /startTran/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[$msgtxt+4]<br /><br /></b>\n";
        &showLogin();
    } else { 
        if (!$form{"tranFile"} || $form{"tranFile"} =~ / / || $form{"tranFile"} =~ /\W/) {
            print "<b><font color=\"red\">$admintext[$msgtxt+7]</font></b><br /><br />\n";
        } else {
            $used = 0;
            open (TL,"< $tranDir$tranlist") || &printError($admintext[$msgtxt+8],"$!");
            while ($filename = <TL>) {
               chomp ($filename);
               if ($filename eq $form{"tranFile"}) {
                  $used = 1;
               }
            }
            close (TL);
            if ($used == 0) {
               $admin{"tranFile"} = $form{"tranFile"} . ".html";
               $admin{"produceTran"} = 1;
               &writeAdminSettings();
               $dateT = scalar (localtime);
               open (TRAN,">> $tranDir$admin{'tranFile'}") || &printError($admintext[9+$msgtxt],"$!");
               print TRAN "<html>\n<head>\n <title>$admintext[10+$msgtxt] \"$form{'tranFile'}\"</title>\n <META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\" />\n <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n";
               print TRAN "<style>\n";
               print TRAN "  .system { color: #ff0000 }\n";
               print TRAN "  .hidden { color: #999999 }\n";
               print TRAN "  .s0 { color: #006600 }\n";
               print TRAN "  .s1 { color: #009933 }\n";
               print TRAN "  .s2 { color: #003399 }\n";
               print TRAN "  .s3 { color: #3300FF }\n";
               print TRAN "  .s4 { color: #336699 }\n";
               print TRAN "  .s5 { color: #0066FF }\n";
               print TRAN "  .s6 { color: #666633 }\n";
               print TRAN "  .s7 { color: #996600 }\n";
               print TRAN "  .s8 { color: #CC6666 }\n";
               print TRAN "  .s9 { color: #663366 }\n";
               print TRAN "  .s10 { color: #990066 }\n";
               print TRAN "  .s11 { color: #CC33CC }\n";
               print TRAN "  .s12 { color: #9966FF }\n";
               print TRAN "  .s13 { color: #CC00FF }\n";
               print TRAN "  .s14 { color: #FF6633 }\n";
               print TRAN "  .s15 { color: #CC6666 }\n";
               print TRAN "</style>\n";
               print TRAN "</head>\n\n<body>\n<h1>$admin{'chatName'} $admintext[11+$msgtxt]</h1>\n<p>$admintext[12+$msgtxt] $dateT</p>\n<table border=\"1\" cellpadding=\"3\">\n";
               close (TRAN);
               open (TL,">> $tranDir$tranlist") || &printError($admintext[8+$msgtxt],"$!");
               print TL "$form{'tranFile'}\n";
               close (TL);
            }
            else {
               $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[13+$msgtxt]</b></font><br />\n";
            }
            &showLogs();
        }
    }

} elsif ($function =~ /stopTran/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $admin{"produceTran"} = 0;
        &writeAdminSettings();
        $dateT = scalar (localtime);
        open (TRAN,">> $tranDir$admin{'tranFile'}") || &printError($admintext[9+$msgtxt],"$!");
        print TRAN "</table><p>$admintext[14+$msgtxt] $dateT</p></body></html>\n";
        close (TRAN);
        &showLogs();
    }

} elsif ($function =~ /delTran/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $count = 0;
        @filename = ();
        open (TL,"< $tranDir$tranlist") || &printError($admintext[2+$msgtxt],"$!");
        while ($filename[$count] = <TL>) {
           $count++;
        }
        close (TL);
        $i;
        open (TN, "> $tranDir$tranlist");
        for($i = 0; $i < $count; $i++) {
           if ($form{$filename[$i]} =~ /delete/) {
              chomp ($filename[$i]);
              if ($admin{"produceTran"} == 1 && "$filename[$i].html" eq $admin{'tranFile'}){
                 print TN "$filename[$i]";
                 $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[15+$msgtxt]</b></font><br />\n";
              }
              else {
                 unlink ("$tranDir$filename[$i].html");
              }
           } else {
              print TN "$filename[$i]";
           }
        }
        close (TN);
        &showLogs();
    }

} elsif ($function =~ /startLog/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        if (!$form{"errLog"} || $form{"errLog"} =~ / / || $form{"errLog"} =~ /\W/) {
            print "<b><font color=\"red\">$admintext[18+$msgtxt]</font></b><br /><br />\n";
        } else {
            $used = 0;
            open (EL,"< $errDir$logList") || &printError($admintext[19+$msgtxt],"$!");
            while ($filename = <EL>) {
               chomp ($filename);
               if ($filename eq $form{"errLog"}) {
                  $used = 1;
               }
            }
            close (EL);
            if ($used == 0) {
               $admin{"produceLog"} = 1;
               $admin{"errLog"} = $form{"errLog"} . ".html";
               &writeAdminSettings();
               $dateT = scalar (localtime);
               open (LOG,">> $errDir$admin{'errLog'}") || &printError($admintext[20+$msgtxt],"$!");
               print LOG "<html>\n<head>\n<title>$admintext[21+$msgtxt] \"$form{'errLog'}\"</title>\n";
               print LOG "<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\" />\n";
               print LOG "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n</head>\n<body>\n";
               print LOG "<h1>$admin{'chatName'} $admintext[22+$msgtxt]</h1>\n";
               print LOG "<p>$admintext[23+$msgtxt] $dateT</p>\n";
               print LOG "<table border=\"1\" cellpadding=\"3\">\n";
               close (LOG);
               open (EL,">> $errDir$logList") || &printError($admintext[19+$msgtxt],"$!");
               print EL "$form{'errLog'}\n";
               close (EL);
            }
            else {
               $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[24+$msgtxt]</b></font><br />\n";
            }
            &showLogs();
        }
    }

} elsif ($function =~ /stopLog/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $admin{"produceLog"} = 0;
        &writeAdminSettings();
        $dateT = scalar (localtime);
        open (LOG,">> $errDir$admin{'errLog'}") || &printError($admintext[20+$msgtxt],"$!");
        print LOG "</table><p>$admintext[25+$msgtxt] $dateT</p></body></html>\n";
        close (LOG);
        &showLogs();
    }

} elsif ($function =~ /delLog/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $count = 0;
        @filename = ();
        open (EL,"< $errDir$logList") || &printError($admintext[19+$msgtxt],"$!");
        while ($filename[$count] = <EL>) {
           $count++;
        }
        close (EL);
        $i;
        open (EL, "> $errDir$logList");
        for($i = 0; $i < $count; $i++) {
           if ($form{$filename[$i]} =~ /delete/) {
              chomp ($filename[$i]);
              if ($admin{"produceLog"} == 1 && "$filename[$i].html" eq $admin{'errLog'}){
                 print EL "$filename[$i]";
                 $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[26+$msgtxt]</b></font><br />\n";
              }
              else {
                  unlink ("$errDir$filename[$i].html");
              }
           } else {
              print EL "$filename[$i]";
           }
        }
        close (EL);
        &showLogs();
    }

} elsif ($function =~ /chooseMode/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $admin{"createID"} = $form{"createID"};
        &writeAdminSettings();
        &showUsers ();
    }

} elsif ($function =~ /email/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $admin{"email"} = $form {"email"};
        $admin{"smtp"} = $form {"smtp"};
        $admin{"subject"} = $form {"subject"};
        &writeAdminSettings();
        open (EM, ">$cgiDIR"."email.txt") || die "E-mail file cannot be opened";
        flock (EM, 2);
        print EM $form {"message"};
        close (EM);
        chmod (0666, "$cgiDIR"."email.txt");
        &showUsers ();
    }

} elsif ($function =~ /createUser/) {
    $minline = 254;
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        if (!$form{"chatID"}) {
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[29+$msgtxt]<br /></b></font>\n";
        }
        elsif (!$form{"password"}) {
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[30+$msgtxt]<br /></b></font>\n";
        }
        elsif ($form{"chatID"} =~ / /i || $form{"chatID"} =~ /\W/) {
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[31+$msgtxt]<br /></b></font>\n";
        }
        elsif (-e "users/$form{\"chatID\"}.prefs") {
            $admintext[32+$msgtxt] =~ s/<PROPOSEDID>/$form{"chatID"}/g;
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[32+$msgtxt]<br /></b></font>\n";
        } else {
            $chatID = $form{"chatID"};
            $password = $form{"password"};
            $prefs{"password"} = $password;
            $prefs{"uniqueID"} = time;
            $prefs{"lastAccessed"} = 0;
            $prefs{"language"} = $admin{"language"};
            &writePrefs();
            if ($admin{"smtp"} && $form{"email"}) {
                open (EM, "<$cgiDIR"."email.txt") || die "Failed to open E-mail file";
                $message = <EM>;
                while ($line = <EM>) {
                    $message = $message.$line;
                }
                close (EM);
                $message =~ s/<CHATID>/$chatID/g;
                $message =~ s/<PASSWORD>/$password/g;
                $message =~ s/<LOGINURL>/$loginURL/g;
                &sendConfirmation($admin{"smtp"}, $form{"email"}, $admin{"email"}, $admin{"chatName"}, $admin{"subject"}, $message);
                $admintext[35+$msgtxt] =~ s/<CHATID>/$chatID/g;
                $adminErrMsg = "<br/><b>$admintext[35+$msgtxt]</b><br/>";
            }
            &defaultPrefs();
        }
        &showUsers ();
    }

} elsif ($function =~ /$activateuser/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        if (!$form{"proposedID"}) {
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[29+$msgtxt]<br /></b></font>\n";
        }
        elsif (-e "users/$form{\"proposedID\"}.prefs") {
            $admintext[31+$msgtxt] =~ s/<PROPOSEDID>/$form{"proposedID"}/g;
            $adminErrMsg = "<br /><font color=\"red\"><b>$admintext[31+$msgtxt]<br /></b></font>\n";
        } else {
            open (RLIST,"<$cgiDIR"."idrequest.lst") || die ("Request file could not be opened");
            @original = <RLIST>;
            close (RLIST);         
            for ($i=0;$original[$i];$i++) {
                chomp ($original[$i]);
                if ($original[$i] =~ /$form{"proposedID"}/ && $form{"proposedID"} =~ /$original[$i]/) {
                    splice (@original, $i, 1);
                    $i--;
                }
            }
            open (RLIST, ">$cgiDIR"."idrequest.lst") || die ("Request file could not be opened");

            foreach $line (@original) {
                print RLIST "$line\n";
            }
            close (RLIST);
            ($chatID,$password,$email) = split(" ", $form{"proposedID"});
            $prefs{"password"} = $password;
            $prefs{"uniqueID"} = time;
            $prefs{"lastAccessed"} = 0;
            $prefs{"language"} = $admin{"language"};
            &writePrefs();
            if ($admin{"smtp"} && $email) {
                open (EM, "<$cgiDIR"."email.txt") || die "Failed to open E-mail file";
                $message = <EM>;
                while ($line = <EM>) {
                    $message = $message.$line;
                }
                close (EM);
                $message =~ s/<CHATID>/$chatID/g;
                $message =~ s/<PASSWORD>/$password/g;
                $message =~ s/<LOGINURL>/$loginURL/g;
                &sendConfirmation($admin{"smtp"}, $email, $admin{"email"}, $admin{"chatName"}, $admin{"subject"}, $message);
                $adminErrMsg = "<br/><b>E-mail sent to $chatID.</b><br/>";
            }
            &defaultPrefs();
        }
        &showUsers ();
    }

} elsif ($function =~ /$declinerequest/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else {
        open (RLIST,"<$cgiDIR"."idrequest.lst") || die ("Request file could not be opened");
        @original = <RLIST>;
        close (RLIST);
        for ($i=0;$original[$i];$i++) {
            chomp ($original[$i]);
            if ($original[$i] =~ /$form{"proposedID"}/ && $form{"proposedID"} =~ /$original[$i]/) {
                splice (@original, $i, 1);
                $i--;
            }
        }
        open (RLIST, ">$cgiDIR"."idrequest.lst") || die ("Request file could not be opened");

        foreach $line (@original) {
            print RLIST "$line\n";
        }
        close (RLIST);
        &showUsers ();
    }

} elsif ($function =~ /$setuseraccess/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else {
        $chatID = $form{'user'};
        &getPrefs();
        $prefs{'accessLevel'} = $form{'access'};
        &writePrefs();
        &defaultPrefs();
        &showUsers();
    }

} elsif ($function =~ /$deletethisuser/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        $delName = $form{"user"};
        &deleteUser($delName);
        &showUsers(); 
    }

} elsif ($function =~ /delAll/) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        opendir(USERS,"users") || &printError("","$!");
        @userFiles = readdir(USERS);
        closedir(USERS);
        foreach $fileT (sort @userFiles) {
            if ($fileT =~ /.prefs/) {
                $fileT =~ s/\.prefs//;
                &deleteUser($fileT);
            }
        }
        open (CLR, "> $cgiDIR"."colour.rcd");
        for ($i = 0; $i < 16; $i++) {
            print CLR "0\n";
        }
        close (CLR);
        &showUsers(); 
    }

} elsif ($function =~ /clearOldChatIDs/i) {
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
       &clearOutOldChatPrefs();
       &showUsers();
    }

} elsif ($function =~ /redisplay/){
    if ($adminPass !~ /$admin{"adminPass"}/ || $admin{"adminPass"} !~ /$adminPass/) {
        $adminErrMsg = "<br /><b>$admintext[1+$msgtxt]<br /><br /></b>\n";
        &showLogin();
    } else { 
        &showAdmin();
    }
    
} else {
    &printError($admintext[$msgtxt+2],$admintext[$msgtxt+3]);

}
exit(0);


####################################################
# Utility Functions

sub writeAdminForm {
    ($functionT,$formNameT) = @_;
    print "<form name=\"$formNameT\" method=\"post\" action=\"$adminURL\">\n";
    print "<input type=\"hidden\" name=\"function\" value=\"$functionT\" />\n";
    print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    
}

# End of Utility Functions
####################################################

####################################################
# Printing Functions

sub showLogin {
    $minline = 65;

    &printHead($admintext[1+$minline], $admintext[1]);
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &printTableDark("<h3>$admin{'chatName'}$admintext[2+$minline]</h3>");
    
    print "$adminErrMsg\n<p>";

    &writeAdminForm("admin","f1");
    print "$admintext[4+$minline] <br /><input type=\"password\" name=\"adminPass\" />
           <input type=\"hidden\" name=\"language\" value=\"$language\">
           <input type=\"submit\" value=\"$admintext[6+$minline]\" /></form></p>\n";   
    print "</body></html>\n";
}

sub showAdmin {
    $minline = 75;

    if ($admin{"msgLifeSpan"} < 650) {
        $m10 = " selected ";
    } elsif ($admin{"msgLifeSpan"} < 950) {
        $m30 = " selected ";
    } elsif ($admin{"msgLifeSpan"} < 1850) {
        $m60 = " selected ";
    } elsif ($admin{"msgLifeSpan"} < 10850) {
        $m180 = " selected ";
    } else {
        $m1D = " selected ";
    }
    if ($admin{"chatSessionLifeSpan"} < 650) {
        $s10 = " selected ";
    } elsif ($admin{"chatSessionLifeSpan"} < 950) {
        $s30 = " selected ";
    } elsif ($admin{"chatSessionLifeSpan"} < 1850) {
        $s60 = " selected ";
    } elsif ($admin{"chatSessionLifeSpan"} < 10850) {
        $s180 = " selected ";
    } else {
        $s1D = " selected ";
    }
    if ($admin{"chatIDLifeSpan"} < 86450) {
        $i1D = " selected ";
    } elsif ($admin{"chatIDLifeSpan"} < 1728050) {
        $i20D = " selected ";	
    } elsif ($admin{"chatIDLifeSpan"} < 2592050) {
        $i1M = " selected ";
    } else {
        $i1Y = " selected ";
    }
    
    &printHead($admintext[1+$minline],"$admintext[1]\n<script type=\"text/javascript\">\nfunction put(){\n  option=document.forms[0].dropdown.options[document.forms[0].dropdown.selectedIndex].text;\n  txt=option;document.forms[0].favorite.value=txt;\n}\n</script>");
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &printTableDark("<h3>$admin{'chatName'}$admintext[2+$minline]</h3>");

    print "$adminErrMsg\n";

    print "<br />\n";

    &printTableDark("<h4>$admintext[5+$minline]</h4>");
    &writeAdminForm("settings","f1");

    # Administrative Password    
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[7+$minline]<br />\n";
    print "<b>$admintext[9+$minline]</b> <input type=\"text\" maxlength=\"10\" name=\"newAdminPass\" value=\"$adminPass\" /></p>\n";

    # Chat Name
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[12+$minline]<br />
           <b>$admintext[14+$minline]</b> <input type=\"text\" maxlength=\"30\" name=\"chatName\" value=\"$admin{'chatName'}\" /></p>\n";

    # Return Link/Text
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
           $admintext[16+$minline]
           </i><br />
           <b>$admintext[18+$minline]</b> <input type=\"text\" size=\"60\" name=\"returnL\" value=\"$admin{'returnL'}\" /><br />
           <b>$admintext[19+$minline]</b> <input type=\"text\" size=\"60\" name=\"returnT\" value=\"$admin{'returnT'}\" /></p>\n";

    # Message Life Span
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[21+$minline]<br />
           <b>$admintext[23+$minline]</b> 
           <select name=\"msgLifeSpan\">
               <option value=\"600\" $m10>$admintext[25+$minline]</option>
               <option value=\"900\" $m30>$admintext[26+$minline]</option>
               <option value=\"1800\" $m60>$admintext[27+$minline]</option>
               <option value=\"10800\" $m180>$admintext[28+$minline]</option>
               <option value=\"86400\" $m1D>$admintext[29+$minline]</option>
           </select></p>\n";

    # Chat Session Life Span
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
           $admintext[31+$minline]<br />
           <b>$admintext[33+$minline]</b>
           <select name=\"chatSessionLifeSpan\">
               <option value=\"600\" $s10>$admintext[35+$minline]</option>
               <option value=\"900\" $s30>$admintext[36+$minline]</option>
               <option value=\"1800\" $s60>$admintext[37+$minline]</option>
               <option value=\"10800\" $s180>$admintext[38+$minline]</option>
               <option value=\"86400\" $s1D>$admintext[39+$minline]</option>
           </select></p>\n";

    # Chat ID Lifespan
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
           $admintext[41+$minline]<br />
           <b>$admintext[43+$minline]</b>
           <select name=\"chatIDLifeSpan\" >
               <option value=\"86400\" $i1D>$admintext[45+$minline]</option>
               <option value=\"1728000\" $i20D>$admintext[46+$minline]</option>
               <option value=\"2592000\" $i1M>$admintext[47+$minline]</option>
               <option value=\"31104000\" $i1Y>$admintext[48+$minline]</option>
           </select></p> \n";

    # Set Maximum Characters
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\" > 
           $admintext[50+$minline] <input type=\"text\" maxlength=\"4\" name=\"maxChar\" value=\"$admin{'maxChar'}\" size=\"4\" STYLE=\"text-align:right\" /> $admintext[52+$minline] <br/> <b>$admintext[53+$minline]</b> <br/>";
    if ($admin{"maxChar"} < 0){
        print "$admintext[54+$minline] <input type=\"checkbox\" name=\"noMax\" value=\"infChar\" Checked > $admintext[55+$minline]</p>\n";
    }
    else {
        print "$admintext[54+$minline] <input type=\"checkbox\" name=\"noMax\" value=\"infChar\" /> $admintext[55+$minline]</p>\n";
    }
    print "<input type=\"hidden\" name=\"language\" value=\"$language\">\n";

    # Default Language
    if ($prefs{"language"} =~ /French/) {
       $fre = "selected";
    } elsif ($prefs{"language"} =~ /Chinese/) {
       $chi = "selected";
    } elsif ($prefs{"language"} =~ /German/) {
       $ger = "selected";
    } elsif ($prefs{"language"} =~ /Italian/) {
       $ita = "selected";
    } elsif ($prefs{"language"} =~ /Japanese/) {
       $jap = "selected";
    } elsif ($prefs{"language"} =~ /Korean/) {
       $kor = "selected";
    } elsif ($prefs{"language"} =~ /Portuguese/) {
       $por = "selected";
    } elsif ($prefs{"language"} =~ /Spanish/) {
       $spa = "selected";
    } else {
       $eng = "selected";
    }

    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\"><b>$admintext[57+$minline] </b>";
    print "<select name=\"language\">
           <option value=\"English\" $eng>$admintext[2+$lang]</option>
           <option value=\"French\" $fre>$admintext[3+$lang]</option>
           <option value=\"Chinese\" $chi>$admintext[4+$lang]</option>
           <option value=\"German\" $ger>$admintext[5+$lang]</option>
           <option value=\"Italian\" $ita>$admintext[6+$lang]</option>
           <option value=\"Japanese\" $jap>$admintext[7+$lang]</option>
           <option value=\"Korean\" $kor>$admintext[8+$lang]</option>
           <option value=\"Portuguese\" $por>$admintext[9+$lang]</option>
           <option value=\"Spanish\" $spa>$admintext[10+$lang]</option>
           </select></p>\n";

    # Footer
    print "<table border=\"0\" width=\"100%\" >\n";
    print "<tr><td><input type=\"reset\" value=\"$admintext[60+$minline]\" /> <input type=\"submit\" value=\"$admintext[61+$minline]\"/></td>\n";
    print "<td align=\"right\"><b>$admintext[20] </b><select name=\"page\" >
               <option value=\"Administrative Settings\" selected >$admintext[22]</option>
               <option value=\"Logs\">$admintext[23]</option>
               <option value=\"Manage Users\">$admintext[24]</option>
           </select>
           <input type=\"submit\" value=\"$admintext[21]\" /></td></tr></table>\n</form>\n";
    print "</p>\n";

    print "</br></br></body></html>\n";

}


sub showLogs {
    $minline = 140;

    &printHead($admintext[1+$minline],"$admintext[1]\n<script type=\"text/javascript\">\nfunction put(){\n  option=document.forms[0].dropdown.options[document.forms[0].dropdown.selectedIndex].text;\n  txt=option;document.forms[0].favorite.value=txt;\n}\n</script>");
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &printTableDark("<h3>$admin{'chatName'}$admintext[2+$minline]</h3>");

    print "$adminErrMsg\n";

    print "<br />\n";

    ### Transcript Functions ###
    $transcript = $minline + 5;

    &printTableDark("<h4>$admintext[$transcript]</h4>");
    print "<br /><p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
              $admintext[2+$transcript] $tranDir $admintext[3+$transcript]<br /><br />\n";
    if ($admin{"produceTran"} > 0) {
        print "$admintext[5+$transcript]
               <a href=\"$htmlURL"."tran/$admin{'tranFile'}\" target=\"_new\">$htmlURL"."tran/$admin{'tranFile'}</a>
               $admintext[6+$transcript]\n";
        print "<form action=\"$adminURL\" method=\"post\" name=\"f8\" style=\"margin: 0;\">\n";
        print "<input type=\"hidden\" name=\"function\" value=\"stopTran\" />\n";
    	print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    	print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    	print "<input type=\"submit\" value=\"$admintext[8+$transcript]\" /></form></p>\n";
    } else {
        print "<form action=\"$adminURL\" method=\"post\" name=\"f9\" style=\"margin: 0;\">\n";
        print "<input type=\"hidden\" name=\"function\" value=\"startTran\" />\n";
    	print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    	print "$admintext[10+$transcript] \n";
    	print "<input type=\"text\" name=\"tranFile\" />\n";
    	print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    	print "<input type=\"submit\" value=\"$admintext[12+$transcript]\" /></form></p>\n";
    }
    if ($admin{"tranFile"} && $admin{"produceTran"} < 1) {
        print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
               $admintext[14+$transcript] 
               <a href=\"$htmlURL"."tran/$admin{'tranFile'}\" target=\"_new\">$htmlURL"."tran/$admin{'tranFile'}</a>
               $admintext[15+$transcript]</p>\n";
    }

    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">\n";
    print "$admintext[17+$transcript]\n";
    writeAdminForm ("delTran", "delTran");
    print "<table width=\"70%\">\n";
    $count = 1;
    open (TRLIST,"< $tranDir$tranlist") || &printError($admintext[6],"$!");
    $trfile = <TRLIST>;
    while ($trfile = <TRLIST>){
       if ($count % 3 == 1){
          print "<tr />";
       }
       print "<td /><input type=\"checkbox\" name=\"$trfile\" value=\"delete\" >
              $count . <a href=\"$htmlURL"."tran/$trfile.html\" target=\"_new\">$trfile</a></td>\n";
       if ($count % 3 == 0){
          print "</tr>";
       }
       $count++;
    }
    close (TRLIST);
    print "</table><input type=\"submit\" value=\"$admintext[19+$transcript]\" /></form></p>\n";


    ### Error Log Functions ###
    $errorlog = $minline + 28;

    &printTableDark("<h4>$admintext[$errorlog]</h4>");
    print "<br /><p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
              $admintext[2+$errorlog] $errDir $admintext[3+$errorlog]<br /><br />\n";
    if ($admin{"produceLog"} > 0) {
        print "$admintext[5+$errorlog]
               <a href=\"$htmlURL"."error/$admin{'errLog'}\" target=\"_new\">$htmlURL"."error/$admin{'errLog'}</a>
               $admintext[6+$errorlog]\n";
        print "<form action=\"$adminURL\" method=\"post\" name=\"endLog\" style=\"margin: 0;\">\n";
        print "<input type=\"hidden\" name=\"function\" value=\"stopLog\" />\n";
    	print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    	print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    	print "<input type=\"submit\" value=\"$admintext[8+$errorlog]\" /></form></p>\n";
    } else {
        print "<form action=\"$adminURL\" method=\"post\" name=\"newLog\" style=\"margin: 0;\">\n";
        print "<input type=\"hidden\" name=\"function\" value=\"startLog\" />\n";
    	print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    	print "$admintext[10+$errorlog] \n";
    	print "<input type=\"text\" name=\"errLog\" />\n";
    	print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    	print "<input type=\"submit\" value=\"$admintext[12+$errorlog]\" /></form></p>\n";
    }
    if ($admin{"errLog"} && $admin{"produceLog"} < 1) {
        print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
               $admintext[14+$errorlog] 
               <a href=\"$htmlURL"."error/$admin{'errLog'}\" target=\"_new\">$htmlURL"."error/$admin{'errLog'}</a>
               $admintext[15+$errorlog]</p>\n";
    }

    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">\n";
    print "$admintext[17+$errorlog]\n";
    writeAdminForm ("delLog", "delLog");
    print "<table width=\"70%\">\n";
    $count = 1;
    open (ERLIST,"< $errDir$logList") || &printError($admintext[18],"$!");
    $erfile = <ERLIST>;
    while ($erfile = <ERLIST>){
       if ($count % 3 == 1){
          print "<tr />";
       }
       print "<td /><input type=\"checkbox\" name=\"$erfile\" value=\"delete\" >
              $count . <a href=\"$htmlURL"."error/$erfile.html\" target=\"_new\">$erfile</a></td>\n";
       if ($count % 3 == 0){
          print "</tr>";
       }
       $count++;
    }
    close (ERLIST);
    print "</table><input type=\"submit\" value=\"$admintext[19+$errorlog]\" /></form></p>\n";

    &writeAdminForm("changePage","page");
    print "<div align=\"right\"><b>$admintext[20] </b><select name=\"page\" >
               <option value=\"Administrative Settings\">$admintext[22]</option>
               <option value=\"Logs\" selected >$admintext[23]</option>
               <option value=\"Manage Users\">$admintext[24]</option>
           </select>
           <input type=\"submit\" value=\"$admintext[21]\" /></div>\n</form>\n";

    print "</br></br></body></html>\n";

}

sub showUsers {
    $minline = 190;

    &printHead($admintext[1+$minline],"$admintext[1]\n<script type=\"text/javascript\">\nfunction put(){\n  option=document.forms[0].dropdown.options[document.forms[0].dropdown.selectedIndex].text;\n  txt=option;document.forms[0].favorite.value=txt;\n}\n</script>");
    &printStylesheet();
    print "<body bgColor=\"$prefs{'back'}\" text=\"$prefs{'front'}\">\n";
    &printTableDark("<h3>$admin{'chatName'}$admintext[2+$minline]</h3>");

    print "$adminErrMsg\n";

    print "<br />\n";

    &printTableDark("<h4>$admintext[5+$minline]</h4>");

    ## Switch between user mode and register user mode
    print "<br /><p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[7+$minline]<br />";
    &writeAdminForm("chooseMode","mngusr");
    if ($admin{"createID"} =~ /register/) {
        print "<input type=\"radio\" name=\"createID\" value=\"create\" /> $admintext[12+$minline]<br />
               <input type=\"radio\" name=\"createID\" value=\"register\" checked /> $admintext[13+$minline]<br />\n";
    } else {
        print "<input type=\"radio\" name=\"createID\" value=\"create\" checked /> $admintext[9+$minline]<br />
               <input type=\"radio\" name=\"createID\" value=\"register\" /> $admintext[10+$minline]<br />\n";
    }
    print "<input type=\"submit\" value=\"$admintext[15+$minline]\" /></form>\n";
    print "</p>\n";

    ## E-mail server
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\" >$admintext[18+$minline]<br/>\n";
    &writeAdminForm ("email", "email");
    print "<table border=\"0\"><tr><td align=\"right\"><b>$admintext[20+$minline]</b></td><td><input type=\"tex\" name=\"smtp\" maxlength=\"100\" size=\"60\" value=\"$admin{'smtp'}\" /></td></tr>
           <tr><td align=\"right\"><b>$admintext[21+$minline]</td><td><input type=\"text\" name=\"email\" size=\"60\" value=\"$admin{'email'}\" /></td></tr>
           <tr><td align=\"right\"><b>$admintext[22+$minline]</td><td><input type=\"text\" name=\"subject\" size=\"60\" value=\"$admin{'subject'}\" /></td></tr>
           <tr><td align=\"right\"><b>$admintext[23+$minline]</b></td><td><textarea name=\"message\" rows=\"6\" cols=\"50\">";
    open (EM, "<$cgiDIR"."email.txt") || die "Failed to open E-mail file";
    while ($line = <EM>) {
        print "$line";
    }
    close (EM);
    print "</textarea></td></tr>
           <tr><td></td><td><input type=\"submit\" value=\"$admintext[25+$minline]\" />\n";
    print "</table></form></p>\n";

    ## Manually create accounts
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">\n";
    &writeAdminForm("createUser","mngusr");
    print "$admintext[28+$minline]
           <table border=\"0\" cellpadding=\"5\" cellspacing=\"0\">
           <tr><td align=\"right\"><b>$admintext[30+$minline] </b></td><td><input type=\"text\" maxlength=\"10\" name=\"chatID\" /></td></tr>
           <tr><td align=\"right\"><b>$admintext[31+$minline] </b></td><td><input type=\"text\" maxlength=\"10\" name=\"password\" /></td></tr>
           <tr><td align=\"right\"><b>$admintext[32+$minline] </b></td><td><input type=\"text\" name=\"email\" /></td></tr>
           <td></td><td><input type=\"submit\" value=\"$admintext[34+$minline]\" /></td></tr></form></table></p>\n";

    ## View new chatID requests
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">\n";
    print "$admintext[37+$minline]\n";
    print "<form name=\"mngusr\" method=\"post\" action=\"$adminURL\">\n";
    print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    print "<select name=\"proposedID\">\n";
    open (LIST,"<$cgiDIR"."idrequest.lst") || die "Failed to read from request file";
    $line = <LIST>;
    foreach $line (<LIST>) {
        chomp ($line);
        ($chatID,$password,$email) = split (" ",$line);
        print "<option value=\"$line\">$chatID [$email]</option>\n";
    }
    close (LIST);
    print "<select><input type =\"submit\" name=\"function\" value=\"$admintext[39+$minline]\" />
           <input type=\"submit\" name=\"function\" value=\"$admintext[40+$minline]\" /></form>\n";
    print "</p>\n";

    ## Control existing account (change access level or delete)
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[43+$minline]\n";
    print "<form name=\"f3\" method=\"post\" action=\"$adminURL\">\n";
    print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    print "<select name=\"user\">\n";
    opendir(USERS,"$cgiDIR"."users") || &printError("","$!");
    @userFiles = readdir(USERS);
    closedir(USERS);
    foreach $selUsr (sort @userFiles) {
        if (index ($selUsr, ".al") > 0) {
            open (USERS,"$cgiDIR"."users/".$selUsr);
            $usrAcc = <USERS>;
            close(USERS);
            $selUsr =~ s/\.al//;
            chomp ($usrAcc);
            print "<option value=\"$selUsr\">$selUsr [$usrAcc]</option>\n";
        }
    }
    print "</select>\n";
    print "<br>$admintext[39+$minline]\n";
    print "<br><input type=\"radio\" name=\"access\" value=1 >$admintext[47+$minline]\n";
    print "<br><input type=\"radio\" name=\"access\" value=2 checked >$admintext[48+$minline]\n";
    print "<br><input type=\"radio\" name=\"access\" value=3>$admintext[49+$minline]\n";
    print "<br><input type=\"submit\" name=\"function\" value=\"$admintext[51+$minline]\" />\n";
    print "<input type=\"submit\" name=\"function\" value=\"$admintext[52+$minline]\" onClick=\"return confirmParDel();\" /></form></p>\n";
    print "<script language=\"javascript\"><!--
           function confirmParDel() {
               if (document.f3.user.selectedIndex >= 0) {
                  if (confirm(\"$admintext[55+$minline] \" + document.f3.user[document.f3.user.selectedIndex].value + \" $admintext[56+$minline]\")) {
                       return true;
                  }
               }
               return false;
           }
           //--></script>\n";

    ## Delete all users
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">$admintext[59+$minline]
           <form action=\"$adminURL\" method=\"post\" name=\"f2\" 
           onSubmit=\"return confirmDel();\" style=\"margin: 0;\">\n";
    print "<input type=\"hidden\" name=\"function\" value=\"delAll\" />\n";
    print "<input type=\"hidden\" name=\"adminPass\" value=\"$adminPass\" />\n";
    print "<input type=\"hidden\" name=\"language\" value=\"$language\" />\n";
    print "<input type=\"submit\" value=\"$admintext[61+$minline]\" /></form></p>\n";
    print "<script language=\"javascript\"><!--
           function confirmDel() {
               if (confirm(\"$admintext[63+$minline]\")) {
                   return true;
               }
               return false;
           }
           //--></script>\n";

    ## Clean up Chat IDs
    print "<p class=\"light\" style=\"margin-left: 30; margin-right: 30;\">
           $admintext[66+$minline]\n";
    &writeAdminForm("clearOldChatIDs", "clearAll");
    print "<input type=\"submit\" value=\"$admintext[68+$minline]\" />\n</form>\n</p>\n";


    &writeAdminForm("changePage","page");
    print "<div align=\"right\"><b>$admintext[20] </b>
           <select name=\"page\" >
               <option value=\"Administrative Settings\">$admintext[22]</option>
               <option value=\"Logs\">$admintext[23]</option>
               <option value=\"Manage Users\" selected>$admintext[24]</option>
           </select>
           <input type=\"submit\" value=\"$admintext[21]\" /></div>\n</form>\n";

    print "</br></br></body></html>\n";
}


# End of Printing Functions
####################################################

