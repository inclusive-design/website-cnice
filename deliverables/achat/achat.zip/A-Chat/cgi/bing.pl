#! /usr/bin/perl

# Accessible Chat Program - Binger - handles Java & ActiveX requests for info
# Copyright 2002, Adaptive Technology Resource Centre, U of Toronto
# Written by: Taras Kowaliw, taras.kowaliw@utoronto.ca
# Last Modified: 12.09.02


BEGIN {
 $cgiDIR = $0;
 $cgiDIR =~ s/bing\.pl$//gi;
 push @INC, $cgiDIR if( $cgiDIR ne "" );
}

print "Content-type: text/html\n\n";
&getCGI();
$chatID = $form{"chatID"};
if (!$chatID) { exit(0); }
&getPrefs();
&howManyMessages();
if ($prefs{"lastChecked"} < $topMsgNum && $prefs{"lastRead"} < $topMsgNum) {
    $prefs{"lastChecked"} = $topMsgNum;
    &writePrefs();
    print "yes\n";
}
print "$topMsgNum $prefs{'lastChecked'} $prefs{'lastRead'} \n";
exit(0);



###############################################
# Some functions from chatutils.ph
# This is faster than requiring the entire file
sub getCGI {
  if ($ENV{'REQUEST_METHOD'} eq 'GET') {
        @pairs = split(/&/, $ENV{'QUERY_STRING'});
  } elsif ($ENV{'REQUEST_METHOD'} eq 'POST') {
        read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
        @pairs = split(/&/, $buffer);
  }
  foreach $pair (@pairs) {
    local($name, $value) = split(/=/, $pair);
    $name =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $form{$name} = $value;
  }
}

sub getPrefs {
    open(PREFS,"<$cgiDIR"."users/$chatID.prefs");
    foreach $prefLine (<PREFS>) {
        chomp($prefLine);
        ($keyT,$valueT) = split("=",$prefLine);
        $keyT =~ s/=//;
        $prefs{$keyT} = $valueT;
    }
    close(PREFS);
    $iT = 0;
    
    # Having some difficulties locking the file... doesn't work
    # on snow, won't work in Windows anyways.
    # Here's a little hack that fixes it, although
    # not particularily well. It works
    # during my testing though.
    while (!$prefs{"lastChecked"} && $iT < 8) {
       sleep 1;
       $iT ++;
       #print "$iT\n";
       open(PREFS,"<$cgiDIR"."users/$chatID.prefs");
       foreach $prefLine (<PREFS>) {
           chomp($prefLine);
           ($keyT,$valueT) = split("=",$prefLine);
           $keyT =~ s/=//;
           $prefs{$keyT} = $valueT;
       }
       close(PREFS);
    }
    $prefs{"lastAccessed"} = time;
}

sub writePrefs {
    open(PREFS,">$cgiDIR"."users/$chatID.prefs") || &printError("writePrefs","$!");
    flock(PREFS,2);
    foreach $prefKey (keys %prefs) {
        $veryT = $prefs{"$prefKey"};
        print PREFS "$prefKey=$veryT\n";
    }
    close(PREFS);
    chmod (0666, "$cgiDIR"."users/$chatID.prefs"); 
}

sub howManyMessages {
    $topMsgNum = 0;
    $bottomMsgNum = 0;
    opendir(MSGS,"$cgiDIR"."msgs") || &printError("howManyMessages","$!");
    @msgs = readdir(MSGS);
    closedir(MSGS);
    foreach $msgFileT (@msgs) {
        if ($msgFileT =~ /.message/) {
            $msgFileT =~ s/.message//;
            if ($msgFileT > $topMsgNum) { $topMsgNum = $msgFileT; }
            if ($msgFileT < $bottomMsgNum || $bottomMsgNum == 0) { $bottomMsgNum = $msgFileT; }
        }
    }
}

# End of chatutil functions
################################################



